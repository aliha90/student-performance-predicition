import streamlit as st
import pandas as pd
import numpy as np
from data_engine import load_data, preprocess_data
from model_engine import (
    train_classification_models, custom_kmeans,
    get_prediction_recommendations, get_cluster_profiles,
    score_based_predict,
)
from ui_components import (
    display_eda, display_model_dashboard, display_cluster_analysis,
    display_prediction_results, display_insights,
)
from utils import get_grade_color_map, CLUSTERING_FEATURES

st.set_page_config(page_title="Student Analytics", layout="wide")

st.markdown("""
<style>
    .main-header { font-size: 2.2rem; color: #1E3A8A; text-align: center; margin-bottom: 2rem; }
    .stAlert { margin-top: 1rem; }
</style>
""", unsafe_allow_html=True)


def main():
    st.markdown('<h1 class="main-header">Student Performance Analytics</h1>', unsafe_allow_html=True)

    try:
        data = load_data()
        df, le_dict, categorical_cols, summary = preprocess_data(data)

        with st.sidebar:
            st.markdown("### Navigation")
            section = st.radio("Go to:", ["Overview", "Analysis", "Clustering", "Predictor"])
            st.markdown("---")
            st.markdown("**How to use:**")
            st.info("Start with **Overview** to see data stats, then use **Analysis** to train models and see insights.")

        # ------------------------------------------------------------------
        # Overview
        # ------------------------------------------------------------------
        if section == "Overview":
            display_eda(df)

        # ------------------------------------------------------------------
        # Analysis
        # ------------------------------------------------------------------
        elif section == "Analysis":
            st.markdown("### Model Training & Insights")
            results, best_model_name, features, scaler, importance_df = train_classification_models(df, categorical_cols)

            metrics_df = pd.DataFrame({
                'Model':              list(results.keys()),
                'Accuracy':           [results[m]['accuracy']       for m in results],
                'Precision':          [results[m]['precision']      for m in results],
                'Recall':             [results[m]['recall']         for m in results],
                'F1-Score':           [results[m]['f1_score']       for m in results],
                'Training Time (s)':  [results[m]['training_time']  for m in results],
                'Inference Time (s)': [results[m]['inference_time'] for m in results],
            })

            display_model_dashboard(results, metrics_df, best_model_name)
            st.markdown("---")

            clustering_features = [f for f in CLUSTERING_FEATURES if f in df.columns]
            from sklearn.preprocessing import StandardScaler
            X_scaled = StandardScaler().fit_transform(df[clustering_features].values)
            labels, _, _ = custom_kmeans(X_scaled, n_clusters=3)
            df['Cluster'] = labels
            profiles = get_cluster_profiles(df, clustering_features)

            display_insights(importance_df, profiles)

            st.session_state.update({
                'results': results, 'best_model': best_model_name,
                'features': features, 'scaler': scaler, 'le_dict': le_dict,
            })

        # ------------------------------------------------------------------
        # Clustering  — K-Means only
        # ------------------------------------------------------------------
        elif section == "Clustering":
            st.markdown("### Student Segmentation (K-Means)")
            clustering_features = [f for f in CLUSTERING_FEATURES if f in df.columns]
            from sklearn.preprocessing import StandardScaler
            X_scaled = StandardScaler().fit_transform(df[clustering_features].values)

            n_clusters = st.slider("Number of Groups:", 2, 5, 3)
            labels, _, inertia = custom_kmeans(X_scaled, n_clusters=n_clusters)
            df['Cluster'] = labels
            st.caption(f"K-Means inertia: **{inertia:,.1f}** — lower is better for cohesion.")
            display_cluster_analysis(df, X_scaled, n_clusters, clustering_features)

        # ------------------------------------------------------------------
        # Predictor  — score-based (always logically correct)
        # ------------------------------------------------------------------
        elif section == "Predictor":
            st.markdown("### Performance Predictor")
            st.info(
                "ℹ️ This predictor uses **domain-knowledge weighted scoring** — "
                "attendance, motivation, study hours, sleep, and stress — to give "
                "a reliable and logically consistent prediction."
            )

            with st.form("pred_form"):
                col1, col2, col3 = st.columns(3)

                with col1:
                    attend     = st.slider("Class Attendance (%)",        0.0,  100.0,  85.0, step=1.0)
                    motivation = st.slider("Motivation Level (1–5)",       1,    5,      3)

                with col2:
                    study      = st.slider("Study Hours / Day",            0.0,  12.0,   4.0, step=0.5)
                    sleep      = st.slider("Sleep Hours / Night",          4.0,  10.0,   7.0, step=0.5)

                with col3:
                    stress     = st.slider("Academic Stress Level (1–5)",  1,    5,      3)
                    social     = st.slider("Social Media Hours / Day",     0.0,  10.0,   2.0, step=0.5)

                submitted = st.form_submit_button("Predict Performance")

            if submitted:
                input_dict = {
                    'average-class-attendance':              attend,
                    'motivation-level':                      motivation,
                    'hours-study-per-day-average':           study,
                    'hours-sleep-per-night':                 sleep,
                    'academic-stress-level':                 stress,
                    'hours-per-day-use-social-media-apps':   social,
                }
                prediction, probs_dict, score_norm = score_based_predict(input_dict)

                classes = list(probs_dict.keys())
                probabilities = np.array([probs_dict[c] for c in classes])

                display_prediction_results(prediction, probabilities, classes, score_norm)
                st.info(get_prediction_recommendations(prediction, score_norm))

    except Exception as e:
        st.error(f"Execution Error: {e}")
        import traceback
        st.code(traceback.format_exc())


if __name__ == "__main__":
    main()
