import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import streamlit as st
from utils import create_grade_bands, DEPARTMENTS_TO_REMOVE, OUTLIER_COLUMNS, NUMERIC_FEATURES

# Columns that are truly categorical (text) and need LabelEncoding
TRULY_CATEGORICAL = [
    'degree-program',
    'use-mobile-during-study-sessions',
    'preferred-study-time',
    'primary-study-method',
    'revise-within-24-hours-after-class',
    'start–preparing-exams',
    'procrastinate',
]

@st.cache_data
def load_data(file_path='synthetic_survey_3000.csv'):
    """Load student performance data from CSV."""
    data = pd.read_csv(file_path)
    return data

@st.cache_data
def preprocess_data(data):
    """
    Perform data cleansing, outlier removal, and categorical encoding.

    Key fix: only TEXT columns in TRULY_CATEGORICAL are label-encoded.
    Numeric ordinal columns (current-semester, academic-stress-level,
    motivation-level) are kept as-is so their real integer values are
    used during both training AND prediction — preventing the
    encode-at-train / raw-value-at-predict mismatch that caused
    inverted predictions.
    """
    df = data.copy()
    initial_count = len(df)
    summary = {}

    # 1. Department filtering
    if 'department' in df.columns:
        df = df[~df['department'].isin(DEPARTMENTS_TO_REMOVE)]
        summary['removed_dept'] = initial_count - len(df)

    # 2. Duplicate removal
    before_dup = len(df)
    df = df.drop_duplicates()
    summary['removed_duplicates'] = before_dup - len(df)

    # 3. Missing value handling
    before_missing = len(df)
    df = df.dropna()
    summary['removed_missing'] = before_missing - len(df)

    # 4. Outlier removal
    before_outliers = len(df)

    # GPA hard range
    if 'GPA-current/previous-semester' in df.columns:
        df = df[(df['GPA-current/previous-semester'] >= 2.0) &
                (df['GPA-current/previous-semester'] <= 4.0)]

    # IQR for behavioural features (mobile excluded — no longer in model)
    def remove_outliers_iqr(df_in, column):
        Q1 = df_in[column].quantile(0.25)
        Q3 = df_in[column].quantile(0.75)
        IQR = Q3 - Q1
        lo = Q1 - 1.5 * IQR
        hi = Q3 + 1.5 * IQR
        return df_in[(df_in[column] >= lo) & (df_in[column] <= hi)]

    for col in OUTLIER_COLUMNS:
        if col != 'GPA-current/previous-semester' and col in df.columns:
            df = remove_outliers_iqr(df, col)

    summary['removed_outliers'] = before_outliers - len(df)
    summary['final_count'] = len(df)
    summary['total_removed'] = initial_count - len(df)

    # 5. Target variable
    df['Grade_Band'] = df['GPA-current/previous-semester'].apply(create_grade_bands)

    # 6. Encode ONLY true text categoricals — keep numeric ordinals untouched
    le_dict = {}
    categorical_cols = []   # only the encoded text columns
    cols_to_drop = []

    for col in TRULY_CATEGORICAL:
        if col not in df.columns:
            continue
        try:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            le_dict[col] = le
            categorical_cols.append(col)
        except Exception:
            cols_to_drop.append(col)

    if cols_to_drop:
        df = df.drop(columns=cols_to_drop)

    return df, le_dict, categorical_cols, summary
