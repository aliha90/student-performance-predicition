import pandas as pd
import numpy as np
import time
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from utils import NUMERIC_FEATURES


# ---------------------------------------------------------------------------
# Classification models  (used for Analysis / model comparison section)
# ---------------------------------------------------------------------------

def train_classification_models(df, categorical_cols):
    """
    Trains multiple classifiers for the Analysis comparison view.
    Only uses NUMERIC_FEATURES so training and prediction use the same
    feature space (no categorical mismatch).
    """
    features = [f for f in NUMERIC_FEATURES if f in df.columns]

    X = df[features]
    y = df['Grade_Band']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled  = scaler.transform(X_test)

    models = {
        'Logistic Regression':    LogisticRegression(max_iter=1000, random_state=42),
        'Decision Tree':          DecisionTreeClassifier(random_state=42, max_depth=5),
        'Random Forest':          RandomForestClassifier(n_estimators=100, random_state=42),
        'Support Vector Machine': SVC(kernel='rbf', random_state=42, probability=True),
    }

    results = {}
    for name, model in models.items():
        t0 = time.time()
        model.fit(X_train_scaled, y_train)
        training_time = time.time() - t0

        y_pred       = model.predict(X_test_scaled)
        y_pred_proba = model.predict_proba(X_test_scaled)

        accuracy = accuracy_score(y_test, y_pred)
        report   = classification_report(y_test, y_pred, output_dict=True)
        cm       = confusion_matrix(y_test, y_pred)

        t0 = time.time()
        model.predict(X_test_scaled[:10])
        inference_time = (time.time() - t0) / 10

        results[name] = {
            'model':                 model,
            'accuracy':              accuracy,
            'precision':             report['weighted avg']['precision'],
            'recall':                report['weighted avg']['recall'],
            'f1_score':              report['weighted avg']['f1-score'],
            'training_time':         training_time,
            'inference_time':        inference_time,
            'predictions':           y_pred,
            'predictions_proba':     y_pred_proba,
            'confusion_matrix':      cm,
            'classification_report': report,
            'y_test':                y_test,
        }

    weights = {'accuracy': 0.3, 'precision': 0.2, 'recall': 0.2, 'f1_score': 0.2, 'speed': 0.1}
    max_inf  = max(r['inference_time'] for r in results.values())
    overall_scores = {
        name: (
            res['accuracy']  * weights['accuracy']  +
            res['precision'] * weights['precision']  +
            res['recall']    * weights['recall']     +
            res['f1_score']  * weights['f1_score']   +
            (1 - res['inference_time'] / max_inf if max_inf > 0 else 1) * weights['speed']
        )
        for name, res in results.items()
    }
    best_model_name = max(overall_scores, key=overall_scores.get)

    rf_model = results['Random Forest']['model']
    importance_df = pd.DataFrame({
        'Feature':    features,
        'Importance': rf_model.feature_importances_,
    }).sort_values('Importance', ascending=False)

    return results, best_model_name, features, scaler, importance_df


# ---------------------------------------------------------------------------
# Score-based predictor  (always logically correct, domain-knowledge weights)
# ---------------------------------------------------------------------------

# Weights reflect which inputs genuinely drive academic performance.
# Signs are chosen so that increasing a "good" factor raises the score.
PREDICTOR_WEIGHTS = {
    'average-class-attendance':              +0.35,   # strongest signal in data (corr 0.23)
    'motivation-level':                      +0.25,   # clear positive driver (corr 0.10)
    'hours-study-per-day-average':           +0.20,   # domain knowledge: more study = better
    'hours-sleep-per-night':                 +0.10,   # healthy sleep supports performance
    'academic-stress-level':                 -0.10,   # high stress hurts performance
    'hours-per-day-use-social-media-apps':   -0.10,   # distraction: more social media = lower performance
}

# Min/max for normalisation (realistic student ranges)
PREDICTOR_RANGES = {
    'average-class-attendance':              (0.0, 100.0),
    'motivation-level':                      (1.0, 5.0),
    'hours-study-per-day-average':           (0.0, 12.0),
    'hours-sleep-per-night':                 (4.0, 10.0),
    'academic-stress-level':                 (1.0, 5.0),
    'hours-per-day-use-social-media-apps':   (0.0, 10.0),
}

def score_based_predict(input_dict):
    """
    Computes a 0-1 performance score using domain-knowledge weights,
    then maps to a grade band and per-class confidence.

    Returns: (prediction, probabilities_dict)
    """
    score = 0.0
    for feature, weight in PREDICTOR_WEIGHTS.items():
        lo, hi = PREDICTOR_RANGES[feature]
        raw   = float(input_dict.get(feature, (lo + hi) / 2))
        norm  = (raw - lo) / (hi - lo)          # 0-1
        norm  = max(0.0, min(1.0, norm))         # clamp
        score += weight * norm

    # score is in roughly [sum of negative weights, sum of positive weights]
    # = [-0.20, +0.90].  Shift and scale to [0, 1].
    score_min, score_max = -0.20, 0.90
    score_norm = (score - score_min) / (score_max - score_min)
    score_norm = max(0.0, min(1.0, score_norm))

    # Band thresholds
    if score_norm >= 0.60:
        prediction = 'High'
    elif score_norm >= 0.38:
        prediction = 'Medium'
    else:
        prediction = 'Low'

    # Soft probability distribution centred on the score
    # High zone centred at 0.80, Medium at 0.50, Low at 0.20
    centres = {'High': 0.80, 'Medium': 0.50, 'Low': 0.20}
    sigma   = 0.18
    raw_probs = {
        band: np.exp(-0.5 * ((score_norm - c) / sigma) ** 2)
        for band, c in centres.items()
    }
    total = sum(raw_probs.values())
    probs = {band: v / total for band, v in raw_probs.items()}

    return prediction, probs, score_norm


# ---------------------------------------------------------------------------
# K-Means
# ---------------------------------------------------------------------------

def custom_kmeans(X, n_clusters=3, max_iter=100):
    """Custom K-Means implementation."""
    np.random.seed(42)
    X = np.array(X, dtype=np.float64)

    if np.any(np.isnan(X)) or np.any(np.isinf(X)):
        col_mean = np.nanmean(X, axis=0)
        inds = np.where(np.isnan(X))
        X[inds] = np.take(col_mean, inds[1])

    n_samples, _ = X.shape
    if n_samples == 0:
        return np.array([]), np.zeros((n_clusters, X.shape[1])), 0

    centroids = X[np.random.choice(n_samples, min(n_clusters, n_samples), replace=False)]
    if n_clusters > n_samples:
        extra = X[np.random.choice(n_samples, n_clusters - n_samples, replace=True)]
        centroids = np.vstack([centroids, extra])

    for _ in range(max_iter):
        distances = np.sqrt(
            ((X[:, np.newaxis, :] - centroids[np.newaxis, :, :]) ** 2).sum(axis=2)
        )
        labels = np.argmin(distances, axis=1)
        new_centroids = np.array([
            X[labels == i].mean(axis=0) if (labels == i).any()
            else X[np.random.choice(n_samples)]
            for i in range(n_clusters)
        ])
        if np.allclose(centroids, new_centroids, rtol=1e-4):
            break
        centroids = new_centroids

    distances_final = np.sqrt(
        ((X[:, np.newaxis, :] - centroids[np.newaxis, :, :]) ** 2).sum(axis=2)
    )
    inertia = np.sum(np.min(distances_final, axis=1) ** 2)
    return labels, centroids, inertia


# ---------------------------------------------------------------------------
# Cluster profiles
# ---------------------------------------------------------------------------

def get_cluster_profiles(df, features):
    """Generates descriptive profiles for identified student clusters."""
    profiles = {}
    for cluster in sorted(df['Cluster'].unique()):
        sub  = df[df['Cluster'] == cluster]
        means = sub[features].mean()
        desc  = []
        if 'hours-study-per-day-average' in means:
            desc.append("High Study Effort" if means['hours-study-per-day-average'] > df['hours-study-per-day-average'].mean() else "Low Study Effort")
        if 'hours-sleep-per-night' in means and means['hours-sleep-per-night'] > df['hours-sleep-per-night'].mean():
            desc.append("Healthy Sleep")
        if 'average-class-attendance' in means and means['average-class-attendance'] > df['average-class-attendance'].mean():
            desc.append("Good Attendance")
        if 'academic-stress-level' in means and means['academic-stress-level'] > df['academic-stress-level'].mean():
            desc.append("High Stress")
        if 'motivation-level' in means and means['motivation-level'] > df['motivation-level'].mean():
            desc.append("High Motivation")
        profiles[cluster] = " | ".join(desc) if desc else "Mixed Profile"
    return profiles


# ---------------------------------------------------------------------------
# Recommendations
# ---------------------------------------------------------------------------

def get_prediction_recommendations(prediction, score_norm=None):
    """Provides academic recommendations based on predicted performance."""
    base = {
        'High': (
            "**Strong Performance Predicted**\n"
            "- Keep up your attendance and study routine.\n"
            "- Consider peer mentoring to reinforce your knowledge.\n"
            "- Explore advanced electives or research opportunities."
        ),
        'Medium': (
            "**Moderate Performance Predicted**\n"
            "- You are on the right track — small improvements can move you to High.\n"
            "- Try to increase class attendance and study consistency.\n"
            "- Manage stress with structured revision schedules."
        ),
        'Low': (
            "**Performance Risk Detected**\n"
            "- Prioritise attending classes — attendance is the strongest predictor.\n"
            "- Even 1-2 extra focused study hours per day makes a measurable difference.\n"
            "- Consult your academic advisor early in the semester."
        ),
    }
    return base.get(prediction, "No specific recommendations available.")
