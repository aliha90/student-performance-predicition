import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.decomposition import PCA
from utils import get_grade_color_map

color_map = get_grade_color_map()

# ---------------------------------------------------------------------------
# EDA
# ---------------------------------------------------------------------------

def display_eda(df):
    tab1, tab2, tab3 = st.tabs(["Overview", "Behavioral Analysis", "Correlations"])

    with tab1:
        st.markdown("### Dataset Overview")
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Total Students Tracked", len(df))
            st.metric("Average GPA", f"{df['GPA-current/previous-semester'].mean():.2f}")
        with col2:
            grade_counts = df['Grade_Band'].value_counts().sort_index()

        fig = px.pie(values=grade_counts.values, names=grade_counts.index,
                     title='Students per Performance Level',
                     color=grade_counts.index, color_discrete_map=color_map)
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("""
        **Data Insight:** Distribution of students across performance levels.

        **Outlier Removal Basis:**
        - **GPA:** Values outside 2.0–4.0 are removed as invalid.
        - **Behavioral Habits:** IQR method removes extreme outliers.
        """)

    with tab2:
        st.markdown("### How Habits Impact Performance")
        col1, col2 = st.columns(2)
        with col1:
            fig = px.box(df, x='Grade_Band', y='hours-study-per-day-average',
                         title='Study Hours by Performance Level',
                         color='Grade_Band', color_discrete_map=color_map)
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            fig = px.box(df, x='Grade_Band', y='average-class-attendance',
                         title='Class Attendance by Performance Level',
                         color='Grade_Band', color_discrete_map=color_map)
            st.plotly_chart(fig, use_container_width=True)

        st.markdown("""
        **How to read this:** Check the median line in each box plot.
        Higher attendance consistently correlates with the 'High' performance level.
        """)

    with tab3:
        st.markdown("### Statistical Correlations")
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        corr_matrix  = df[numeric_cols].corr()
        fig = px.imshow(corr_matrix, text_auto=True, color_continuous_scale='RdBu',
                        title='Relationship Heatmap')
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("""
        **Interpretation:** Dark red = positive correlation (both increase together).
        Blue = negative correlation (one increases as the other decreases).
        """)


# ---------------------------------------------------------------------------
# Model Dashboard
# ---------------------------------------------------------------------------

def display_model_dashboard(results, metrics_df, best_model_name):
    st.markdown("### Predictive Model Comparison")
    col1, col2 = st.columns([2, 1])
    with col1:
        melted = metrics_df.melt(id_vars=['Model'],
                                 value_vars=['Accuracy', 'Precision', 'Recall', 'F1-Score'],
                                 var_name='Metric', value_name='Score')
        fig = px.bar(melted, x='Model', y='Score', color='Metric',
                     barmode='group', title='Model Accuracy Comparison')
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        st.success(f"**Top Model:** {best_model_name}")
        st.markdown(f"""
        **Note:** The {best_model_name} had the best composite score across
        accuracy, precision, recall, F1, and speed.

        Accuracy ~0.45–0.55 is expected here because this dataset's
        behavioural features have weak correlation with GPA by design
        (synthetic data). The **Predictor** section uses a domain-knowledge
        scoring model instead, which always behaves logically.
        """)


# ---------------------------------------------------------------------------
# Cluster Analysis
# ---------------------------------------------------------------------------

def display_cluster_analysis(df, X_scaled, n_clusters, features):
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_scaled)
    viz_df = pd.DataFrame({
        'PC1': X_pca[:, 0], 'PC2': X_pca[:, 1],
        'Group': df['Cluster'].astype(str), 'Level': df['Grade_Band'],
    })

    st.markdown("#### Student Groups (K-Means)")
    col1, col2 = st.columns(2)
    with col1:
        fig1 = px.scatter(viz_df, x='PC1', y='PC2', color='Group',
                          title='Behavioural Segments')
        st.plotly_chart(fig1, use_container_width=True)
    with col2:
        fig2 = px.scatter(viz_df, x='PC1', y='PC2', color='Level',
                          title='Segments by Academic Level',
                          color_discrete_map=color_map)
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown("""
    **Understanding Segmentation:** Left chart groups by *habits*. Right chart shows
    *actual performance*. Overlap between a cluster and a performance level reveals a
    behavioural success pattern.
    """)

    st.markdown("#### Cluster Summary Statistics")
    label_map = {
        'hours-study-per-day-average':         'Study Hrs/Day',
        'hours-sleep-per-night':               'Sleep Hrs/Night',
        'average-class-attendance':            'Attendance %',
        'hours-per-day-use-social-media-apps': 'Social Media Hrs',
        'academic-stress-level':               'Stress (1-5)',
        'motivation-level':                    'Motivation (1-5)',
    }
    summary = df.groupby('Cluster')[features].mean().round(2)
    summary.columns = [label_map.get(c, c) for c in summary.columns]
    st.dataframe(summary, use_container_width=True)


# ---------------------------------------------------------------------------
# Insights — Key Success Factors (mobile removed)
# ---------------------------------------------------------------------------

def display_insights(importance_df, profile_dict):
    st.markdown("### Actionable Success Factors")
    tab1, tab2 = st.tabs(["Key Success Factors", "Student Personas"])

    with tab1:
        st.markdown("#### What drives academic success?")

        label_map = {
            'current-semester':                    'Current Semester',
            'hours-study-per-day-average':         'Study Hours/Day',
            'hours-sleep-per-night':               'Sleep Hours/Night',
            'average-class-attendance':            'Class Attendance (%)',
            'hours-per-day-use-social-media-apps': 'Social Media Hours/Day',
            'academic-stress-level':               'Academic Stress Level',
            'motivation-level':                    'Motivation Level',
        }

        # Exclude mobile phone — not in model features
        filtered = importance_df[
            importance_df['Feature'] != 'hours-per-day-use-mobile phone'
        ].copy()
        filtered['Feature Label'] = filtered['Feature'].map(lambda f: label_map.get(f, f))
        filtered = filtered.sort_values('Importance', ascending=True)

        fig = px.bar(filtered, x='Importance', y='Feature Label', orientation='h',
                     title='Feature Impact Ranking (higher = stronger predictor)',
                     color='Importance', color_continuous_scale='Viridis')
        fig.update_layout(yaxis_title='', xaxis_title='Importance Score',
                          coloraxis_showscale=False)
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("""
        **Note:** Features at the top are the strongest predictors based on the
        Random Forest model. **Attendance** and **motivation** are the most impactful
        positive drivers. **Social media usage** and **stress** are key negative
        factors — reducing both can meaningfully improve academic performance.
        """)

    with tab2:
        st.markdown("#### Typical Student Profiles")
        cols = st.columns(len(profile_dict))
        for i, (cluster, profile) in enumerate(profile_dict.items()):
            with cols[i]:
                st.markdown(f"""
                <div style="background-color:#F0F9FF;padding:1rem;border-radius:8px;
                            border-top:4px solid #0EA5E9;">
                    <h4 style="color:#0369A1;margin:0;">Group {cluster}</h4>
                    <p style="font-size:0.9rem;">{profile}</p>
                </div>
                """, unsafe_allow_html=True)
        st.markdown("<br>**How to use:** Use these profiles to design targeted academic support.", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Prediction Results  (with score gauge)
# ---------------------------------------------------------------------------

def display_prediction_results(prediction, probabilities, classes, score_norm=None):
    prediction_color = color_map.get(prediction, '#6B7280')

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"""
        <div style="background-color:{prediction_color};color:white;padding:2rem;
                    border-radius:10px;text-align:center;">
            <h3 style="margin:0;">Predicted Performance</h3>
            <h1 style="font-size:3.5rem;margin:0.5rem 0;">{prediction}</h1>
        </div>
        """, unsafe_allow_html=True)

        if score_norm is not None:
            st.markdown("<br>", unsafe_allow_html=True)
            fig_gauge = go.Figure(go.Indicator(
                mode="gauge+number",
                value=round(score_norm * 100, 1),
                title={'text': "Performance Score (0–100)"},
                gauge={
                    'axis': {'range': [0, 100]},
                    'bar': {'color': prediction_color},
                    'steps': [
                        {'range': [0, 38],  'color': '#FEE2E2'},
                        {'range': [38, 60], 'color': '#FEF3C7'},
                        {'range': [60, 100],'color': '#D1FAE5'},
                    ],
                    'threshold': {'line': {'color': 'black', 'width': 3},
                                  'thickness': 0.75, 'value': score_norm * 100},
                }
            ))
            fig_gauge.update_layout(height=220, margin=dict(t=30, b=10, l=20, r=20))
            st.plotly_chart(fig_gauge, use_container_width=True)

    with col2:
        prob_df = pd.DataFrame({'Level': classes, 'Confidence %': probabilities * 100})
        fig = px.bar(prob_df, x='Confidence %', y='Level',
                     title='Model Confidence', orientation='h',
                     color='Level', color_discrete_map=color_map)
        st.plotly_chart(fig, use_container_width=True)
